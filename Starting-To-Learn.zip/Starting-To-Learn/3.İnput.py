Name = input('Adınız?')
Number1 = input('Number1 = ') #input
Number2 = input('Number2 = ') 
print(Number1+Number2)
print(int(Number1)+int(Number2))
x = 'Thanks.'
print(x) 