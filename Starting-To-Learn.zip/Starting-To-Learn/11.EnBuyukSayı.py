number1 = int(input('1. tam sayı = '))
number2 = int(input('2. tam sayı = '))
number3 = int(input('3. tam sayı = '))

if number1 >= number2 and number1>=number3:
  enBuyuk = number1

elif number2>=number1 and number2>=number3:
  enBuyuk = number2

else:
  enBuyuk = number3

print('En büyük tam sayı = '+ str(enBuyuk))