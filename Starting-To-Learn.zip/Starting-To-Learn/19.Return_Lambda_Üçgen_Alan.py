a = int(input('Dik kenar uzunluğu giriniz.'))
b = int(input('Dik kenar uzunluğu giriniz.'))
def dikUcgenAlaniHesapla(a,b):
  return a*b/2

alan = dikUcgenAlaniHesapla(a,b)
print(alan)

dikUcgenAlaniHesapla2 = lambda a,b : a*b/2 #lambda def ve returnlü olanın aynıssını yazar ana tek satıra indirger.

print(dikUcgenAlaniHesapla2(3,6))
