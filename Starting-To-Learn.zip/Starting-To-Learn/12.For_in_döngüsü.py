sehirler = ['Ankara', 'İstanbul', 'İzmir']

for sehir in sehirler:
  if sehir != 'Ankara':
    print(sehir + ' için kod: ' + sehir[0:3] )
    print('*********')