#Ucgendepisagorbagintisiformulu = (dik kenar 1)^2 + (dik kenar 2)^2 = (Hipotenus)^2
#Kisaca a^2+b^2=c^2

a = int(input('1. dik kenarı giriniz.'))
b = int(input('2. dik kenarı giriniz.'))
formul = (a**2 + b**2)
print('Hipotenüsün karesi = '+ str(formul))