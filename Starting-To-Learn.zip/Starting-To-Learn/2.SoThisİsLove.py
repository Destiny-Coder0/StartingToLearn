like = "Seni seviyorum."
extra = "Seni bekliyordum."
more = "İyi ki geldin."
welcome = "Hoş geldin her şeyim"

print(welcome)
print(extra+" "+more+" "+like)

love = 10
hate = -10
you = "Harikasın."
notyou = " Berbatsın."
nothing = "Eh işte."

if love>hate:
 print(you)

elif love<hate:
 print(notyou)

else:
 print(nothing)
  
  
def tell():
 pass
x = ["Ben", "Sen", "Hayat"]
for x in x:
  print("<caption>"+x+"<caption>")


print(len(x))