set = {1,2,3} #set of integers
set1 = {4,5,6, 'Hello World', (7,8,9)} #set of mixed datatypes
#sette eleman tekrarı olmaz.

studentsSet = {'Engin', 'Derin', 'Ahmet','Mehmet'}
print(studentsSet)
for student in studentsSet:
 print(student)

print('Derin'in studentsSet)
if 'Derin' in studentsSet:
 print('Listede var.')

studentsSet.add('Hakan')
print(studentsSet)

studentsSet.update(['Mert','Eylül', 'Bilge'])
print(studentsSet)

studentsSet.remove('Engin')
print(studentsSet)

studentsSet.discard('Ahmet')
print(studentsSet)

#del studentsSet #delete
#print(studentsSet)

studentsSet2 = set('Ayşe', 'Hasan', 'Fatma') #Burada çalışmıyor.