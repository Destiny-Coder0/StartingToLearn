list = [] #empty_list
list1 = [1, 2, 3] #list of integers
list2 = [4, 'Hello World', 5, 6, 'Thats it'] #list with mixed datatypes
list3 = ['management', [7,8,9], ['a', 'b']] #nested list

ogrenciler = ['Engin', 'Ahmet','Mehmet','Ayşe','Fatma' ]
ogrenciler.append('Hilal')
ogrenciler.remove('Ayşe')
print(ogrenciler[3])
print(ogrenciler)

sehirler = list(('İstanbul','Ankara','İzmir', 'Bursa'))
print(sehirler)
print(len(sehirler))
