sehirler = ['İstanbul','Ankara','İzmir', 'Bursa']
sehirler.clear() #Listeyi temizledi
print(sehirler)

sehirler = ['İstanbul','Ankara','İzmir', 'Bursa', 'Ankara']
print('Ankara sayısı = ' + str(sehirler.count('Ankara'))) #Sayısını saydı
print('Ankara indexi = ' + str(sehirler.index('Ankara'))) #Kaçıncı sırada

sehirler.pop(1) #indexe göre silme işlemi, remove olsaydı direkt Ankara yazardık.
print(sehirler)

sehirler.insert(0,'Muğla') #İndexe elaman ekleme
print(sehirler)

sehirler.reverse() #Terse çevirme
print(sehirler)

sehirler3 = sehirler.copy() #Kopya oluşturma
sehirler2 = sehirler
sehirler2 [0] = 'Zonguldak'
print(sehirler)
print(sehirler2)
print(sehirler3)

sehirler.extend(sehirler3) #Listeleri birleştirme
print(sehirler)

sehirler.sort() #Alfabetik sıralama
print(sehirler)
