for x in range(1,101):
 print(x)

#YA DA

for x in range(100):
  print(x + 1)

#2şerli atlatmak

for x in range(1,100,2):
 print(x)