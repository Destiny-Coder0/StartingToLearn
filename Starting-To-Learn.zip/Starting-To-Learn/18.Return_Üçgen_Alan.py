a = int(input('Dik kenar uzunluğu giriniz.'))
b = int(input('Dik kenar uzunluğu giriniz.'))
def dikUcgenAlaniHesapla(a,b):
  return a*b/2

alan = dikUcgenAlaniHesapla(a,b)
print(alan)
