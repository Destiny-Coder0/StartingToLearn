#UcgendeAlan = Taban * Yukseklik / 2

taban = int(input('Taban ölçüsünü giriniz.'))
yukseklik = int(input('Yükseklik ölçüsünü giriniz.'))
formul = taban * yukseklik / 2
print('Üçgenin alanı '+ str(formul))