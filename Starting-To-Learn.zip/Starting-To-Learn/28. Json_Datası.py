import json

data = '{"firstName":"Engin","lastName":"Demiroğ"}'

y = json.loads(data)  #stringi json datasına çevirme.

print(y['firstName'])
print(y['lastName'])

customer = {
  'firstName': 'Engin',
  'email': 'engindemirog@gmail.com'
}

customerJson = json.dumps(customer) #Python sözlüğünü Json datasına çevirme.
print(customer)

print(json.dumps('Masa')) #Json datasına çevirilmiş kelime.