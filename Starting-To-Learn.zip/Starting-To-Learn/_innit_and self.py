class Dusman:
  def __init__(self,isim='Dusman',kalanCan=500,saldiriGucu=10,mermiSayisi=5):
    self.isim=isim
    self.kalanCan=kalanCan
    self.saldiriGucu=saldiriGucu
    self.mermiSayisi=mermiSayisi

  def print(self):
   print('Basılıyor...')
   print('İsim:',self.isim,'Kalan can:',self.kalanCan,'Saldırı Gücü:',self.saldiriGucu,'Mermi Sayısı:',self.mermisayisi)


dusman1= Dusman('Ali',100,15,10)
dusman2= Dusman('Veli',70,20,15)
dusman3= Dusman()

print('Düsman 1 yükleniyor.')
print(dusman1)
print('Düsman 2 yükleniyor.')
print(dusman2)
print('Düşman 3 yükleniyor.')
print(dusman3)