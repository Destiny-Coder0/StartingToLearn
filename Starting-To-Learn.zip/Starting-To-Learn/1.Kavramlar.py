age = 18 #integer
ability = 90.5 #float
name = "Dilara" #string
tel = "5458320310"
message = "Selam olsun sizlere"

print(tel)
print(float(tel) + 20)
print(message[2:10]) #substring
print(message[:7])
print(message[6:])
newMessage = message[:11]
print(newMessage)
print(len(message)) #length_Uzunluk
print(len(newMessage))

newMessage2 = message[len(message)-1:len(message)]
print(newMessage2)

print(message.upper()) #lower_upper
print(message.lower())

#message = me
print(message.replace("i","ı")) #replace
