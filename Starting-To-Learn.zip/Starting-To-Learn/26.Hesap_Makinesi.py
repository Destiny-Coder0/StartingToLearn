#Amaç: Basit bir hesap makinesi yapmak. Kullanıcıdan operasyon seçmesi istenir. Bunun için 1'den 4'e kadar rakamlar verilir ve seçtiği rakama göre operasyon gerçekleşir. Ardından kullanıcıdan ilk 1. sayıyı isteyecek, daha sonra ise 2. sayıyı isteyecek ve bu 2 sayıyı operasyona göre hesaba koyacak.
def topla(sayi1,sayi2):
  return(sayi1+sayi2)
  
def cıkar(sayi1,sayi2):
  return(sayi1-sayi2)
  
def carp(sayi1,sayi2):
  return(sayi1*sayi2)
  
def bol(sayi1,sayi2):
  return(sayi1/sayi2)
  
print('Operasyon:')
print('1 : Topla')
print('2 : Çıkar')
print('3 : Çarp')
print('4 : Böl')

secenek = input('Operasyon seçiniz. ')
 
sayi1 = int(input('1. sayıyı giriniz. '))
sayi2 = int(input('2. sayıyı giriniz. '))

if secenek == '1':
  print('Sonuç: '+ str(topla(sayi1,sayi2)))
  
elif secenek == '2':
  print('Sonuç: '+ str(cıkar(sayi1,sayi2)))

elif secenek == '3':
  print('Sonuç: '+ str(carp(sayi1,sayi2)))

elif secenek == '4':
  print('Sonuç: '+ str(bol(sayi1,sayi2)))

else:
  print('Geçersiz seçenek girildi.')