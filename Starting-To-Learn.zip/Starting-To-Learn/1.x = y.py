x = 10 
y = 20

x,y = y,x

# temp = x
# x = y 
# y = temp

print('x = ' + str(x))
print('y = ' + str(y))