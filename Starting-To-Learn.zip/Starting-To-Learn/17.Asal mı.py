#Asal sayılar = 2,3,5,7,11,13,17,19,...

sayi = int(input('Sayı giriniz: '))
asalMi = True
for x in range(2,sayi):
  if (sayi % x) == 0:
   print('Asal değil.')
  else:
    print('Asal.')
  break
