donusumOrani = 0.621371192
km = int(input('Kaç kilometre?'))
mil = km * donusumOrani
print(str(km) + ' kilometre = '+ str(mil) + ' mil eder.')