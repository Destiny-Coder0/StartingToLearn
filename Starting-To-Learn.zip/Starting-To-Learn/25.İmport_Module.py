import Module1  #import başka bir dosyadan o komutu çağırmaya yarar.

Module1.topla(2,3)
Module1.carp(2,4)
print('-----------------------------------')

import Module1 as m  #Dosya adı değiştirilip kısaltılabilir.
m.topla(1,3)
m.carp(3,4)
print('-----------------------------------')

print(m.customer['firstName']) 

print('-----------------------------------')

from Module1 import topla  #from ile yalnızca tek bir komutu da çağırabiliriz.
topla(2,4)