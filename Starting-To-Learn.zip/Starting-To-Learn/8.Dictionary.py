#dictionary sete benzer sadece anahtar kelimeler tanım içerir. Masa : Table gibi.
dict = {} #empty dictionary
dict1 = {1 : 'apple', 2: 'ball'} #dictionary with integer keys
dict2 = {'name' : 'John', 1 : [2,3,4]} #dictionary with mixed keys
dict3 = dict({1 : 'apple', 2: 'ball'}) #using dict()
dict4 = dict([(1,'apple'), (2, 'ball')]) #from sequence having each item as a pair

sozluk = { 'book' : 'kitap',
          'table' : 'masa'
         }

sozluk['book'] = 'kitap1'
sozluk['pencil'] = 'kalem'
del(sozluk['book'])
print(sozluk)