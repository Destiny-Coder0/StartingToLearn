class Person():
  def __init__(self,firstName,lastName,age):
   self.firstName = firstName
   self.lastName = lastName
   self.age = age

person1 = Person ('Engin', 'Demiroğ',33)
print(person1.firstName)

class Worker(Person):
  def __init__(self,salary):
    self.salary = salary

class Customer(Person):
  def __init__(self, creditCardNumber):

Ahmet = Worker()
Mehmet = Customer()

Mehmet.age
Mehmet.firstName #gibi