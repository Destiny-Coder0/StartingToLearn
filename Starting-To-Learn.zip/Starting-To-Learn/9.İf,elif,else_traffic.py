lights = ['red', 'yellow', 'green']
currentLight = lights[0]

if currentLight == 'red':
  print('STOP!')

elif currentLight == 'yellow':
  print('READY!')

else currentLight == 'green':
  print('GO!')