non = '    Hayır;istemiyorum;olmaz   '
print(non.split(';')) #split_ayırdı
print(non.strip() #Baş ve sondaki boşlukları kaldırma