sayac = 1
sonuc = 0

while sayac<=10:
  sonuc = sonuc+sayac
  sayac = sayac+1

print(sonuc)