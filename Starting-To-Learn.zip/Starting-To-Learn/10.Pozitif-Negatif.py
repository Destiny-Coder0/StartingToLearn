number = int(input('Sayı giriniz.'))

if number > 0 :
  print('Sayınız '+ 'pozitif sayıdır.')

elif number == 0 :
  print('Sayınız '+'nötr sayıdır.')

else:
  print('Sayınız '+ 'negatif sayıdır.')