#Faktöriyel örneği: 5! = 1.2.3.4.5

sayi = int(input('Sayı: '))
faktoriyel = 1

if sayi<0:
 print('Negatif sayıların faktöriyeli hesaplanamaz.')
elif sayi==0:
 print('Sonuç: 1')
else:
 for x in range(1,sayi+1):
   faktoriyel = faktoriyel * x
 print('Sonuç: ' , faktoriyel)