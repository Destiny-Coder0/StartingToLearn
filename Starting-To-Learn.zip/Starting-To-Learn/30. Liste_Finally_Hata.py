liste = [7, 'Engin', 0, 3, '6']

for x in liste:
  try:
    print('Sayı: '+ str(x))
    sonuc: 1/int(x)
    print('Sonuç: '+ str(sonuc))
    
  except:
    print(str(x)+' hesaplanamadı.')

  finally: #Finally dosyayı kapatır ve altta olan diğer işlemler devam eder.
    print('İşlemler bitti.')