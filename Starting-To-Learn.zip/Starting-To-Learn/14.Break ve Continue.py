sehirler = ['Ankara', 'İstanbul', 'İzmir']

for sehir in sehirler:
  if sehir == 'İstanbul':
    break #İstanbul'a gelince durmasını sağlar.
    continue #İstanbul'u atlayıp devam etmesini sağlar.
    print(sehir + ' için kod: ' + sehir[0:3] )
    print('*********')