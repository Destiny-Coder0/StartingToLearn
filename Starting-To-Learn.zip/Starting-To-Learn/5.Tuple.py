tuple = () #empty tuple
tuple1 = (1,2,3) #tuple having integers
tuple2 = (4, 'Hello World', 5, 6, 'Hi') #tuple with mixed datatypes
tuple3 = ('Welcome', [7,8,9], (10,11,12)) #nested tuple

#You can change a list but you can't change a TUPLE.

tupleList = (2,4,6, 'Turkiye', [7,8,9], [])
list = [2,4,6, 'Turkiye', [7,8,9], ()]
list[0] = 1
#tupleList [0] = 1

print(tupleList[-2])
print(list[-2])

print(tupleList[1:2])
print(list[1:2])

print(len(tupleList))
print(len(list))

#İmportant thing :
nontupleThing = ('Mıstık') #str
tupleThing = ('Mıstık',) #tuple

print(type(nontupleThing))
print(type(tupleThing))