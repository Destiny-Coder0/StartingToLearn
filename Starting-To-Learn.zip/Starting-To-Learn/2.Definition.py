def selamVer(isim = 'ziyaretçi'): #definition = tanım
  print('Merhaba ' + isim)

selamVer('Dilara')
selamVer('Ömer')
selamVer('Arda')
selamVer()

def selamVer2(isim = 'ziyaretçi', soyisim = ' arkadaş'):
  print('Merhaba ' + isim + soyisim)

selamVer2()
selamVer2('Engin', ' Demiroğ')