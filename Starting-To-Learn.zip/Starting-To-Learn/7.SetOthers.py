setA = {
    1,
    2,
    3,
    4,
    5,
}
setB = {1, 2, 3, 6, 7, 8}
#union iki seti birleştirir ama aynı verileri tekrarlamaz. Birleşim kümesi gibi.
print(setA | setB)
#ya da
print(setA.union(setB))

#intersection kesişimi alır. Kesişim kümesi gibi.
print(setA & setB)
print(setA.intersection(setB))

#difference farkı alır. A fark B kümesi gibi.
print(setA - setB)
print(setB - setA)
print(setA.difference(setB))
print(setB.difference(setA))

#symmetric listeden kesişimi çıkarır. A fark B ve B fark A'nın birleşimi gibi.
print(setA ^ setB)
print(setA.symmetric_difference(setB))
