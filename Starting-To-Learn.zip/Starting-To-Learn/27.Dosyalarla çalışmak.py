#Dosyalarla çalışmak
# r = read yani dosyayı okumak
# a = append yani dosyaya eklemek
# w = write yani dosyanın üstüne yazmak #Direkt dosyayı silip üstüne yazıyor dikkat!!!
# x = create yani yeni dosya oluşturmak

f = open('musteri.txt')
# print(f.read(5)) #ilk beşi okur

# print(f.read()) #dosyayı okur

#print(f.readline())
#print(f.readline()) #satır satır okur

#for l in f:              #Tamamını okur
 # print(f.readline())

# *YA DA*
for l in f:
  print(l)

f.close() #dosyayı kapatır

fileToAppend = open('ogrenciler.txt', 'a')
fileToAppend.write('\n')  # \n ifadesi enter anlamına gelir ve satır başı atılır.
fileToAppend.write('Engin')
fileToAppend.write('\n')
fileToAppend.write('Derin')

# import.os
# os.remove('ogrenciler.txt')  # DOSYAYI SİLER.

a = open('deneme.txt')

if  os.path.exists('deneme.txt'):
  os.remove('deneme.txt')

else:
  print('Dosya yok.')


# os.rmdr('...') , '...' boş bir klasör olsun örneğin bu şekilde silinebilir.