number = int(input('Kaç yıldız olsun?'))
yildiz = ''

for x in range(1, number+1):
  yildiz = yildiz + '*'
  print(yildiz)